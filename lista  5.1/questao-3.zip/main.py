import f

n=f.fib("Digite um número: ")