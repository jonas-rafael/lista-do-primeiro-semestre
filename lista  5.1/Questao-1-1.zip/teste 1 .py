while True:
    nota= float(input(mensagem))

    if 0 <= nota <= 10:
      break
    else:
      print("Nota invalida!")
  return nota
    while True:
      letra= float(input(mensagem))
      if letra == "a" or "A":
        med= (n1+n2+n3)/3
        print(med)
      elif letra == "p" or "P":
        med= (n1*5 + n2*3 + n3*2 ) / (5+3+2)
        print(med)
  